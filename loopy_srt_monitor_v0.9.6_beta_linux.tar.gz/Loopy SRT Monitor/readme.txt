Loopy SRT Stats Monitor v0.9.6
==============================

Files required
--------------

Settings are stored in your "Documents\Loopy SRT Monitor" folder.

To complete the install and allow the program to communicate with OBS, run "install.cmd" (or "install.txt" in Linux) to install/update "obs-websocket-js". 
This should have already been completed during the install, but can be done manually if required.

The latest version of "Loopy SRT Monitor" is available at https://github.com/loopy750/SRT-Stats-Monitor/releases/latest

"obs-websocket-js" requires Node.js to be installed.
Download it from https://nodejs.org/

OBS WebSocket is required for OBS.
Latest release available at: https://github.com/obsproject/obs-websocket/releases/latest

The latest release of Node.js is available at: https://nodejs.org/
The latest release of OBS WebSocket is available at: https://github.com/obsproject/obs-websocket/releases/latest


Notes
-----

- OBS WebSocket v4.9.0 or newer required.
- Scene names are case-sensitive, must be eight words or less, and must contain at least one source.
- Media Sources must have "Restart playback when source becomes active" disabled.
- Disable "Enable System Tray Alerts" in WebSockets Server Settings to avoid message spam, or use "NodejsFileSystem" setting "2".
- Minimum recommended options for SRT protocol are "mode", "latency", & "timeout" - see https://obsproject.com/wiki/Streaming-With-SRT-Or-RIST-Protocols
- Ideal starting SRT protocol options are "?mode=listener&latency=3000000&timeout=5000000", & "Reconnect Delay" set to 1 second.
- Latest OBS Studio release recommended for the best stability with SRT protocol.
- Light mode can be used by editing shortcut "Properties" and appending "-light" to the target.


Configuring 'config.ini'
------------------------

[config]
	This is the main config section for the program.
	NOTE: OBS scene names are case-sensitive, must be eight words or less, and must contain at least one source.

xWindowPosition
	Default vertical window position in pixels.
	NOTE: This is where you want the program to be placed on startup, not the screen resolution.

yWindowPosition
	Default horizontal window position in pixels.
	NOTE: This is where you want the program to be placed on startup, not the screen resolution.

StreamFailDelay
	Recommended: 5-15
	Value in seconds to trigger OBS scene change when stream/s is down.

SceneOK
	The OBS scene name for the live stream i.e. the main scene. (eg. IRL live stream)
	* This value is NOT used when 'MultiCameraSwitch' is enabled. See below.

SceneFail
	The OBS scene name for fallback video. (eg. 4G fallback video)

SceneIntro
	The OBS scene name for first launch when no stream is running. (eg. IRL live intro)

SceneBypass
	Possible values: none, scene name
	The OBS scene that, when manually selected, will pause the program and prevent any automatic scene changes. The default setting of "none" disables this feature. 
	For additional bypass scenes, add SceneBypass2, SceneBypass3 ... SceneBypass8, SceneBypass9 to the config file.

MediaSource1
	The name of the OBS "Media Source" for stream #1 ("Restart playback when source becomes active" should be unchecked).

MediaSource2
	The name of the OBS "Media Source" for stream #2 ("Restart playback when source becomes active" should be unchecked).
	* This value is NOT used when 'MultiCameraSwitch' is disabled. See below.

WebSocketAddress
	IP address and port of OBS WebSocket. By default this is "127.0.0.1:4444". In most cases you will not need to change this.

WebSocketPassword
	Password of OBS WebSocket.

CheckUpdateOnStartup
	Possible values: false, true
	When enabled, checks if a program update is available on startup. Updates can be found at https://github.com/loopy750/SRT-Stats-Monitor/releases/latest


[features]
	Additional features this program offers.

SceneLBREnabled
	Possible values: false, true
	While freezing is detected during playback, the OBS scene will be changed to a "low bitrate" solution. This scene usually contains the same sources as what's 
	currently used, but with an indicator for the viewer that there are bandwidth issues. However, the sources can be anything of your choosing. The scene must be 
	appended with "LBR". For example, the "low bitrate" scene for "Main" must be labeled "Main LBR".
	* This also works when 'MultiCameraSwitch' is enabled. See below.

SceneLBRDelay
	Recommended: 0, 1, 2
	The number of seconds of low bitrate streaming detected before scene is switched to LBR. Useful if LBR scene switching becomes too problematic or undesirable. The 
	default setting of "0" disables this feature.
	* Requires 'SceneLBREnabled' to also be enabled to be operational.

Scene2LBRDisabled
	Possible values: false, true
	When enabled, the LBR "low bitrate" scene for the second stream will be disabled.
	* Requires 'SceneLBREnabled' to also be enabled to be operational.

ConnectionsLog
	Possible values: false, true
	When enabled, appends useful connection information for debugging or troubleshooting to a log file located in "Documents\Loopy SRT Monitor\Temp".

FileStatusOutput
	Possible values: false, true
	When enabled, outputs the current stream status to a file called 'outputStatus.txt' to the program's Temp folder for public/personal use. For example, one use 
	case scenario could be for a mIRC script that can be used to read the file and output to a chat room for realtime monitoring.

NodejsFileSystem
	Possible values: 0, 1, 2
	The method used for how the program communicates with Node.js and OBS WebSocket.
	0 - The default and slowest method used. Hidden terminal windows are opened and closed which increases the communication latency.
	1 - Slightly faster method compared to the default. The console window is always visible and running which can help reduce communication latency when running 
		scripts via node.js.
	2 - Node.js runs in an external window and a persistent connection is established for collecting Scene and Media Source information. This prevents OBS WebSocket 
		from being flooded with connections. Due to the terminal window running externally, file access conflicts could occur, causing an error. When this happens the 
		program will recover after a few seconds. The external terminal window will need to be manually closed. 

RISTFailMode1
	Possible values: false, true
	When enabled, 'SceneFail' will be activated when "Media Source" for stream #1 is in a frozen state. This may be required when using the RIST protocol.

RISTFailMode2
	Possible values: false, true
	When enabled, 'SceneFail' will be activated when "Media Source" for stream #2 is in a frozen state. This may be required when using the RIST protocol.

jsEncoding
	Possible values: json, msgpack
	The OBS WebSocket connection encoding used. The default and fastest subprotocol is json and should not need to be changed.

AllowResize
	Possible values: false, true
	Allows the window to be resized. Note that text may appear blurry. If Windows Display Scaling is used and causes the window to appear smaller than expected, this 
	can be resolved by enabling "High DPI scaling override behaviour" for the .exe file and selecting the "System" option. For more information, see 
	https://www.digitaltrends.com/computing/how-to-adjust-high-dpi-scaling-in-windows-10/. Pressing F10 restores window size.


[multi-camera-switch]
	This section is for monitoring two SRT streams and automatically switching scenes accordingly. ALL values within [config] with the exception of 'SceneOK' are 
	used/shared. This is because there is no longer one "main" scene, but three (stream 1, stream 2, & stream 1+2).

MultiCameraSwitch
	Possible values: false, true
	When disabled, nothing in this section will have any effect on the program. When enabled, selected OBS scene will be determined by the stream/s running. Stream #1 
	will activate 'TitleScene1', stream #2 will activate 'TitleScene2', and both stream #1 and stream #2 running simultaneously will activate 'TitleScene12'.
	* Remember: 'SceneOK' is NOT used when this is enabled, but should be set to the same value.

TitleScene1
	The OBS scene name used when ONLY stream #1 is active.

TitleScene2
	The OBS scene name used when ONLY stream #2 is active.

TitleScene12
	The OBS scene name used when BOTH stream #1 and stream #2 are active.

ReturnPreviousScene
	Possible values: false, true
	When enabled, any scene changes set MANUALLY will be remembered if 'SceneFail' is ever triggered. However, scene change is ONLY remembered until there is a stream 
	change. For example, if the scene for stream #1 is manually changed, and either stream #2 or stream #1+#2 become active, stream #1 will revert back to its ORIGINAL 
	state the next time it becomes the active scene. For each stream to ALWAYS remember its new (i.e. manually selected) scene, 'returnPreviousScene' must also be 
	enabled. An example of when this could be used is an upside down camera scene. This setting should be disabled unless required. See below.

ReturnPreviousSceneRemember=true
	Possible values: false, true
	When enabled, any scene changes set MANUALLY will always be remembered, regardless of any changes to stream/s running. For example, if a scene is MANUALLY changed 
	while stream #1 is active, the value of 'TitleScene1' will be replaced by the new scene name and becomes permanent, until the program is either restarted or 
	another MANUAL change is made. This setting should be disabled unless required.
	* Requires 'returnPreviousScene' to also be enabled to be operational.


List of default config.ini settings
-----------------------------------

[config]
xWindowPosition=480
yWindowPosition=320
StreamFailDelay=10
SceneOK=Main
SceneFail=BRB
SceneIntro=Intro
SceneBypass=none
MediaSource1=Media Source
MediaSource2=Media Source 2
WebSocketAddress=127.0.0.1:4455
WebSocketPassword=PassWS
CheckUpdateOnStartup=false

[features]
SceneLBREnabled=false
SceneLBRDelay=0
Scene2LBRDisabled=false
ConnectionsLog=false
FileStatusOutput=false
NodejsFileSystem=0
RISTFailMode1=false
RISTFailMode2=false
jsEncoding=json
AllowResize=false

[multi-camera-switch]
MultiCameraSwitch=false
TitleScene1=Main
TitleScene2=Main 2
TitleScene12=Main 1+2
ReturnPreviousScene=false
ReturnPreviousSceneRemember=false


Keyboard & mouse controls
-------------------------

F10
	Restore window size

F11
	Toggle fullscreen

CTRL + D
	Debug

CTRL + A
	Always on top


Command line parameters:
------------------------

-light
	Launch program in light mode.


Changelog
---------

v0.9.6
------
- Added support for OBS WebSocket 5.x
- Added 'SceneLBRDelay' configuration - see readme.txt for instructions
- Added 'AllowResize' configuration - see readme.txt for instructions
- Added 'RISTFailMode1' configuration - see readme.txt for instructions
- Added 'RISTFailMode2' configuration - see readme.txt for instructions
- Added 'jsEncoding' configuration - see readme.txt for instructions
- Added light mode option - see readme.txt for instructions
- Released portable version for Windows
- Released version for Linux
- Minor UI changes
- Minor fixes

v0.9.5
------
- Added 'SceneBypass' configuration - see readme.txt for instructions
- Added 'Scene2LBRDisabled' configuration - see readme.txt for instructions
- Added 'NodejsFileSystem' configuration - see readme.txt for instructions
- Added 'Always on top' option
- Fixed an error that may have caused some scenes to not be detected

v0.9.4
------
- Added low bitrate scene option for both single-stream and multi-stream configurations
- Added option to log connection activity in a log file stored in "Documents\Loopy SRT Monitor\Temp"
- Added IP ping displayed (usually localhost)
- Adjusted window size, slightly smaller

v0.9.2
------
- Improved error checking on startup
- Minor UI changes

v0.9.1
------
- Minor UI and code changes

v0.9.0
------
- Initial release

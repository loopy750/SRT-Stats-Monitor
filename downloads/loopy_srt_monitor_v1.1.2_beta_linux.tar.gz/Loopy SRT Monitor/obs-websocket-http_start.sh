#!/bin/bash
cd "$(dirname "$0")"
./obs-websocket-http
echo
read -p "Press any key to continue . . . " -n 1 -s -t 30

